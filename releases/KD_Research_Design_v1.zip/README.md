# Where should a small CNN spend its teacher queries?

Knowledge distillation study · design version 1.0 · 22 November 2026

A teacher can give a student more than the correct label. Two crops of a picture may both be labeled “fox,” while the teacher's predictions move from fox to dog when the face is cropped out. It costs a teacher evaluation to learn what happened on each crop. This study asks whether those changes tell us which training images deserve extra evaluations.

The first experiment gives every method a budget of **180,000 teacher predictions** for 45,000 CIFAR-100 fitting images. One method stores four predictions per image. Another stores six for half the images and two for the rest, chosen randomly within each class. The proposed method uses that same six/two allocation, giving extra views to the images on which the teacher changed its prediction most. Every image enters student training exactly once per epoch. A win over random allocation would isolate the value of choosing the images. A win over four per image would justify the extra scoring procedure.

## Start here

| File | What it answers |
| --- | --- |
| [Literature review](research/LITERATURE.md) | What do the two supplied papers establish, and which other approaches are closest? |
| [Filled experiment brief](research/EXPERIMENT_BRIEF.md) | What is the question, the primary comparison and the decision rule? |
| [Experimental protocol](research/PROTOCOL.md) | What exactly are the datasets, CNNs, configurations, seed blocks and cost boundaries? |
| [Run matrix](research/RUN_MATRIX.csv) | Which teacher or student runs in each block, which cache is reused, and what does each fit cost in calls and updates? |
| [Kaggle and evidence guide](research/RUN_GUIDE.md) | What runs today, how will the measured stage recover, and which records must exist? |
| [Paper draft](research/PAPER_DRAFT.md) | How could the question, rationale and methods be presented in a paper? |
| [Progress and verification](research/PROGRESS.md) | Which files and numerical checks exist, and which results are still pending? |
| [Decisions, mistakes and improvements](research/DECISIONS_AND_CORRECTIONS.md) | Which assumptions changed, why, and what would require a new protocol version? |
| [First Kaggle notebook](notebooks/00_cache_preflight.ipynb) | Run the disposable cache/replay checks and optionally audit the original CIFAR-100 archive. |

The comparison starts with a ResNet-34 teacher and a ResNet-18 student on CIFAR-100. Further experiments change the student to MobileNetV4-Conv-Small on the same data, or keep the residual pair and change the dataset to CIFAR-10 or Tiny ImageNet. This layout lets us interpret an architecture change separately from a dataset change. The maximum budget is 57 student fits and three dataset-specific teachers. The first measured block is one teacher and six students.

The local replay fixture is complete. The first benchmark accuracy, energy measurement and scientific selection are pending. The notebook in this version is the preflight entry point. Its synthetic outputs carry no scientific accuracy claim.

## Original project inputs

The two PDFs remain at the project root. Their titles, file digests and relevant pages are in the literature review. The supplied [experiment handoff](https://chatgpt.com/library?file_id=libfile_5ea50c3a6da481918874897eba59e758&account_id=personal) and [blank experiment brief](https://chatgpt.com/library?file_id=libfile_1448a3ce80fc8191bcb84dc9d61e7e2b&account_id=personal) provided the record-keeping and execution requirements. This project uses its own image data, model identities, run records and publication destination.

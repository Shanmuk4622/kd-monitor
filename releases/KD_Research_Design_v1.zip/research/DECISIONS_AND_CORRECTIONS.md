# Decisions, mistakes and improvements

## Decisions made before the first measured fit

| Date | Decision | Reason and consequence |
| --- | --- | --- |
| 22 Nov 2026 | Use CIFAR-100 for one primary question, then vary the model or dataset one at a time. | A large leaderboard would hide why a student improved. CIFAR-100 offers 100 classes and a manageable first target. The transfer set remains incomplete as a full architecture-by-dataset factorial. |
| 22 Nov 2026 | Use a fixed average of four views and a two/six allocation. | It leaves two paid pilot views for a within-image comparison, ensures equal per-class quotas, and makes every slot's exposure count an integer over 60 epochs. The optimal cache size is outside the claim. |
| 22 Nov 2026 | Distinguish the shuffled, uniform and entropy controls. | The shuffled policy isolates who receives extra views. Uniform checks whether unequal allocation helps. Entropy tests a simpler explanation for any gain. |
| 22 Nov 2026 | Pair five independently redrawn blocks and use one teacher per dataset. | Pairing controls student initialization and augmentation randomness. Teacher-seed variability remains open. Five blocks are a compute choice and do not guarantee precision for a small effect. |
| 22 Nov 2026 | Use a +0.30-point useful gain and a −0.50-point quality margin for the separate energy comparison. | These are prospective research tolerances selected for this design. They are not thresholds reported by the supplied papers. |
| 22 Nov 2026 | Retain final-epoch student accuracy as the primary endpoint. | A validation-best epoch can differ between arms. A fixed endpoint ensures exactly the same number of updates and source-image exposures. |
| 22 Nov 2026 | Prefer dense FP32 logits and native-resolution crops. | This prevents label quantization and resized small images from becoming extra explanations. The conclusion will be specific to this augmentation family. |
| 22 Nov 2026 | Treat existing tyre and early-exit material as project context only. | The attached handoff's Kaggle, evidence and recovery rules transfer. Its data, old results, repository paths and completed model identities belong to different experiments. |

## Mistakes found and corrections made

| Observation | Correction and check |
| --- | --- |
| The local project directory contained two PDFs. A broad search for experiment guidance returned other research projects. | Resolved the two exact Markdown filenames, read the handoff and empty brief, and filled a new copy for this project. Both input identities are in the root README. |
| The first PDF extraction used the Windows console's default encoding and stopped at a mathematical character. | Read the local PDFs with Unicode output, and visually checked Table 2 of the AIoT paper and Table 4 of the PLOS paper. Kept reported quantities tied to their hardware and comparator. |
| An initial design that compared live KD with a saved bank changed view diversity at the same time as delivery. | Added an exact same-pixel logit/loss/gradient check, and made the primary scientific contrast between two finite banks of equal cost. |
| Charging only extra allocation queries would make the ranking procedure appear cheaper than it is. | Include both probes in each standalone budget. The fixture counts actual build forwards, and records extra parity-audit forwards separately. Store physical shared work and standalone-equivalent counts as different fields. |
| An early environment check imported torchvision after torch and encountered a Windows imaging DLL load error. | Verified the primary ResNets after adding the environment's DLL directory and importing Pillow before torchvision. The portable cache fixture uses tensor crops and has no Pillow dependency. No packages were replaced. |
| The local environment lacks timm, and the original CIFAR-100 binary was unavailable in the project. | The MobileNetV4 check and official-data audit remain pending. Verified the source architecture identity, made the CIFAR input explicit and tested role/duplicate handling with a constructed fixture. |

## Improvements to test or implement

1. Qualify the measured writer and full-update restart on dual T4 with a verified source snapshot, a recorded peak-space forecast and a real cross-session restore.
2. Check on additional, independent fitting views whether two probes give a reproducible instability ranking. Charge those queries to diagnostics.
3. If a causal claim about the soft targets becomes important, add a separately versioned pair of label-only fits on the identical guided and shuffled banks. The current primary comparison measures the whole view-allocation policy.
4. If a five-block interval spans harm and useful gain, disclose the range. A future precision study needs a prospective seed budget and a new analysis record.

For subsequent work append the date, old rule, new rule, trigger, affected artifacts and whether any validation or final outcomes had already been seen. Preserve failed run identities and the original protocol.

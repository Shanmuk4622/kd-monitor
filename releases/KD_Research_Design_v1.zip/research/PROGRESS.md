# Progress, validation receipts and open work

## Status on 22 November 2026

| Stage | State | Evidence |
| --- | --- | --- |
| Two supplied PDFs and Markdown instructions | Reviewed | [Evidence register](LITERATURE.md) and [filled brief](EXPERIMENT_BRIEF.md) |
| Additional prior art and paper question | Reviewed and specified | FKD, consistent teaching, dataset reinforcement, FerKD, adaptive sampling and class coverage mapped to explicit controls |
| Preregistered-style design | Specified locally | [Experimental protocol](PROTOCOL.md). Archive the final source/version before measured execution. No external preregistration is claimed. |
| Run-by-run plan | Enumerated | [60-row run matrix](RUN_MATRIX.csv), including dependencies, independent cache builds, later reuse and planned update counts |
| First notebook | Implemented, executed locally | [Source notebook](../notebooks/00_cache_preflight.ipynb) and [executed copy](../evidence/local_preflight/executed_preflight.ipynb) |
| Synthetic allocation, live/cache equivalence and split logic | Passed on local inputs | [Machine-readable fixture receipt](../evidence/local_preflight/fixture/receipt.json) |
| Actual CIFAR-100 split | Writer implemented, original archive pending | Expected binary digest in [run guide](RUN_GUIDE.md). Exact post-audit validation and test denominators are unknown. |
| Small-image residual models | Local forward shapes checked with random weights | Counts below. Trained checkpoints pending. |
| MobileNetV4 and all measured trainer functions | Specified | Local timm is absent. Dataset-specific classifier, Kaggle runtime, evidence writers and complete-update continuation require qualification. |
| Dual T4, live Hub restore and campaign budget | Pending | No occupied remote session, confirmed destination, sensor trace, measured T4 throughput or storage projection in this version. |
| Benchmark fits and independent results audit | 0 of 57 planned students, 0 of 3 teachers | No measured accuracy, energy saving, selected model or remote revision. |
| Manuscript | Introduction and methods drafted | [Working manuscript](PAPER_DRAFT.md). Results and conclusions await evidence. |

## Local engineering receipt

The executed notebook ran its five code cells in a fresh local Jupyter kernel. Software was Python 3.11.15, PyTorch 2.5.1+cu121 and NumPy 2.4.6 in cv_conda. Visible accelerators were one NVIDIA GeForce GTX 1650 and the CPU. The T4 environment is a separate qualification target.

The [SHA-256 inventory](../SHA256SUMS.txt) identifies the sources, submitted notebook, executed notebook, protocol and retained fixture files for this design snapshot. Future measured-run receipts must bind the actual benchmark data and checkpoint identities as well.

| Check | CPU | GTX 1650 | Acceptance |
| --- | ---: | ---: | --- |
| Standalone teacher image evaluations per policy | 100 | 100 | Exactly 4 × 25 fitting images, including both pilot views |
| Dense FP32 target bytes per policy | 1,200 | 1,200 | 100 rows × 3 classes × 4 bytes |
| Largest absolute cached vs recomputed logit difference | 0 | 0 | ≤ 0.00001 |
| Largest absolute KD loss difference | 0.000000059605 | 0.000000059605 | ≤ 0.000001 |
| Largest absolute student-gradient difference | 0.000000007451 | 0.000000007451 | ≤ 0.00001 |

All four policies passed the per-class budget, distinct slot and 60-epoch exposure checks, including the odd-sized class with a four-view median. The fixture checks frozen-teacher gradients and reopens the persisted view index and logits before the comparison. Per device, it physically used 50 shared probe evaluations, four sets of 50 extra allocations and 108 independent verification forwards per policy. The 100-call standalone figure describes cache construction for one policy. [CPU policy rows](../evidence/local_preflight/fixture/cpu/policy_checks.csv) · [GPU policy rows](../evidence/local_preflight/fixture/cuda-0/policy_checks.csv)

The separate split fixture deliberately introduced overlap. Eight candidate training records produced four fitting rows, three eligible validation rows and one excluded validation row. Four final candidates produced two eligible rows and two exclusions. It exported zero final labels. These are synthetic counts.

| Residual architecture | Parameters for 10, 100, 200 classes | Tested outputs with batch two |
| --- | --- | --- |
| ResNet-18 | 11,173,962 / 11,220,132 / 11,271,432 | 2 × 10 at 32 px, 2 × 100 at 32 px, 2 × 200 at 64 px |
| ResNet-34 | 21,282,122 / 21,328,292 / 21,379,592 | 2 × 10 at 32 px, 2 × 100 at 32 px, 2 × 200 at 64 px |

## Experiment sequence

The next measured milestone is the CIFAR-100 ResNet-34 teacher and the six seed-42 ResNet-18 arms. Before that milestone, complete a real manifest, qualify the scientific trainer and complete-update restore, and lock the dataset/teacher/protocol identities. The five-block primary comparison comes before wider claims about CNNs or datasets.

Keep each later entry in this log tied to a run, a file and a verification level. Report the observed outcome, failed checks, and the next unresolved dependency. Use [decisions and corrections](DECISIONS_AND_CORRECTIONS.md) for protocol changes or errors.
